package com.example.healthappproject

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SetRecordAdapter(private val context: Context) : RecyclerView.Adapter<SetRecordAdapter.SetRecordViewHolder>() {

    private val setRecords = mutableListOf<String>() // 운동 세트 기록을 저장할 리스트

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SetRecordViewHolder {
        val view = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_1, parent, false)
        return SetRecordViewHolder(view)
    }

    override fun onBindViewHolder(holder: SetRecordViewHolder, position: Int) {
        holder.setText(setRecords[position])
    }

    override fun getItemCount(): Int = setRecords.size

    fun addNewSetRecord(setText: String) {
        setRecords.add(setText)
        notifyItemInserted(setRecords.size - 1)
    }

    inner class SetRecordViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textView: TextView = itemView.findViewById(android.R.id.text1)

        fun setText(text: String) {
            textView.text = text
        }
    }
}
