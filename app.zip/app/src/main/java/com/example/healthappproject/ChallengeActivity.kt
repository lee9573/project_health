package com.example.healthappproject

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.healthappproject.databinding.ActivityChallengeBinding

// ChallengeActivity는 AppCompatActivity를 상속하여 챌린지 화면을 구성하는 Activity입니다.
class ChallengeActivity : AppCompatActivity() {

    // ActivityChallengeBinding을 통해 XML 레이아웃 요소에 접근
    private lateinit var binding: ActivityChallengeBinding

    // 사용자가 완료한 챌린지 개수
    private var completedChallenges = 0

    // 총 챌린지 개수
    private val totalChallenges = 9

    // 챌린지 데이터를 하드코딩된 리스트로 정의
    private val challengesData = listOf(
        "Push-up Challenge", "Running Challenge", "Sit-up Challenge",
        "Squat Challenge", "Plank Challenge", "Jumping Jack Challenge",
        "Burpee Challenge", "Lunge Challenge", "Mountain Climber Challenge"
    )

    // 현재 로드된 챌린지 목록을 저장할 리스트, 지연 초기화를 통해 필요할 때 초기화
    private val currentChallengeSet by lazy { ArrayList<String>() }

    // 액티비티가 생성될 때 호출되는 메서드
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChallengeBinding.inflate(layoutInflater) // 뷰 바인딩 초기화
        setContentView(binding.root) // 레이아웃을 화면에 설정

        // 유튜브 썸네일을 클릭하면 유튜브 웹사이트로 이동하는 인텐트를 실행
        binding.youtubeThumbnail.setOnClickListener {
            val youtubeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            startActivity(youtubeIntent)
        }

        // 새로운 챌린지를 로드하고 리사이클러뷰 설정
        loadNewChallenges()
        setupRecyclerView()
    }

    // 리사이클러뷰의 레이아웃 매니저와 어댑터를 설정하는 메서드
    private fun setupRecyclerView() {
        binding.challengesRecyclerView.layoutManager = LinearLayoutManager(this) // 세로 스크롤을 위한 LinearLayoutManager 설정
        binding.challengesRecyclerView.adapter = ChallengeAdapter(currentChallengeSet) { isChecked ->
            handleCheckBoxChange(isChecked) // 체크박스 상태가 변경될 때 호출되는 콜백 함수 전달
        }
    }

    // 새로운 챌린지 세트를 로드하고 진행률을 초기화하는 메서드
    private fun loadNewChallenges() {
        currentChallengeSet.clear() // 기존의 챌린지 목록을 초기화
        currentChallengeSet.addAll(challengesData.shuffled().take(totalChallenges)) // 무작위로 9개의 챌린지를 선택하여 추가
        completedChallenges = 0 // 완료된 챌린지 개수 초기화
        updateProgressBar() // 초기화 후 진행률 업데이트
    }

    // 체크박스 상태 변경 시 호출되는 메서드
    private fun handleCheckBoxChange(isChecked: Boolean) {
        if (isChecked) {
            completedChallenges++ // 체크되었을 경우 완료된 챌린지 개수 증가
            Toast.makeText(this, "Challenge Completed!", Toast.LENGTH_SHORT).show() // 완료 메시지 출력
        } else {
            completedChallenges-- // 체크 해제 시 완료된 챌린지 개수 감소
        }
        updateProgressBar() // 체크박스 상태 변경에 따라 진행률 업데이트

        // 모든 챌린지를 완료했을 때 메시지를 표시하고 새로운 챌린지를 로드
        if (completedChallenges == totalChallenges) {
            Toast.makeText(this, "All Challenges Completed!", Toast.LENGTH_LONG).show() // 완료 메시지 출력
            loadNewChallenges() // 새로운 챌린지 목록 로드
            binding.challengesRecyclerView.adapter?.notifyDataSetChanged() // 리사이클러뷰 갱신
        }
    }

    // 진행률을 업데이트하여 ProgressBar에 반영
    private fun updateProgressBar() {
        val progress = (completedChallenges.toFloat() / totalChallenges * 100).toInt() // 완료된 챌린지 비율 계산
        binding.challengeProgress.progress = progress // 계산된 진행률을 ProgressBar에 설정
    }
}
