package com.example.healthappproject

import android.content.Intent
import android.net.Uri // URL 기능
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.healthappproject.databinding.ActivityChallengeBinding // 뷰 바인딩을 통해 XML파일에 접근


class ChallengeActivity : AppCompatActivity() { // 상속

    private lateinit var binding: ActivityChallengeBinding

    private var completedChallenges = 0 //사용자가 완료한 챌린지 개수 저장
    private val totalChallenges = 9 //전체 챌린지 개수

    private val challengesData = listOf(
        "Push-up Challenge", "Running Challenge", "Sit-up Challenge",
        "Squat Challenge", "Plank Challenge", "Jumping Jack Challenge",
        "Burpee Challenge", "Lunge Challenge", "Mountain Climber Challenge"
    ) //챌린지 리스트, 한정적인 데이터 양이기에 api와 firebase를 이용하여 추후 코드 수정 예정

    private val currentChallengeSet by lazy{ ArrayList<String>() } //현재 로드된 챌린지목록을 저장할 리스트 형성
    /* 여기서 bylazy를 써서 지연 초기화를 한 이유는, 액티비티가 생성되는 순간 즉시 초기화할 필요는 없고,
     필요할 때 첫 번째 접근 시 초기화되기 때문에, 메모리 사용을 최적화할 수 있습니다.
     사용자가 loadNewChallenges()를 호출하지 않는다면, currentChallengeSet은 초기화되지 않습니다.*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) //oncreate: 액티비티가 생성될 때 호출
        setContentView(binding.root) //레이아웃을 화면에 표현

        binding.youtubeThumbnail.setOnClickListener { // 썸네일 클릭시 Intent로 유튜브 앱이나 웹 브라우저를 열어줌. 추후 url 데이터 수집 및 수정 예정
            val youtubeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            startActivity(youtubeIntent)
        }

        loadNewChallenges() // 새로운 챌린지 세트 로드
        setupChallengeCheckBoxes() // 체크박스에 필요한 설정 수행
    }

    private fun setupChallengeCheckBoxes() { //체크박스 리스트 형성
        val checkBoxes = listOf(
            binding.challenge1Check,
            binding.challenge2Check,
            binding.challenge3Check,
            binding.challenge4Check,
            binding.challenge5Check,
            binding.challenge6Check,
            binding.challenge7Check,
            binding.challenge8Check,
            binding.challenge9Check
        )

        checkBoxes.forEachIndexed { index, checkBox -> // 각 체크박스에 랜덤하게 선택된 챌린지 이름 설정
            checkBox.text = currentChallengeSet[index]
            checkBox.isChecked = false //초기 상태는 체크되지 않은 상태


            checkBox.setOnCheckedChangeListener { _, isChecked -> // 사용자가 체크박스를 체크하거나 해제 할때 함수 호출
                handleCheckBoxChange(isChecked)
            }
        }

    }

    private fun loadNewChallenges() {
        currentChallengeSet.clear() //기존 챌린지 목록 초기화
        currentChallengeSet.addAll(challengesData.shuffled().take(totalChallenges))
        /* 리스트에서 무작위로 챌린지 9개를 선택하여 currentChallengeSet에 추가하는 작업을 수행, shuffle을 이용하여 리스트를 무직위로 섞음
        addall로 리스트 요소를 현재 리시트에 추가 */

        val checkBoxes = listOf( // 각 체크박스에 새로운 챌린지 할당
            binding.challenge1Check,
            binding.challenge2Check,
            binding.challenge3Check,
            binding.challenge4Check,
            binding.challenge5Check,
            binding.challenge6Check,
            binding.challenge7Check,
            binding.challenge8Check,
            binding.challenge9Check
        )

        checkBoxes.forEachIndexed { index, checkBox -> //새로운 챌린지가 갱신됐으므로 체크박스 텍스트 갱신
            checkBox.text = currentChallengeSet[index]
            checkBox.isChecked = false
            checkBox.setOnCheckedChangeListener { _, isChecked ->
                handleCheckBoxChange(isChecked)
            }
        }

        completedChallenges = 0 //사용자의 챌린지 완료 개수 초기화
        updateProgressBar() //챌린지 진행률을 나타내는 게이지 업데이트
    }

    private fun handleCheckBoxChange(isChecked: Boolean) { // 체크박스 상태 변경 함수
        if (isChecked) {
            completedChallenges++ //완료된 챌린지 개수 하나 증가
            Toast.makeText(this, "Challenge Completed!", Toast.LENGTH_SHORT).show()
        } else {
            completedChallenges-- // 체크 해제시 챌린지 완료 개수 하나 감소
        }
        updateProgressBar() //체크에 따라 진행률 반영

        if (completedChallenges == totalChallenges) { /* 모든 챌린지 완성시 텍스트 출력 후 새로운 챌린지 로드,
         주마다 챌린지를 갱신하기 위해 추후 수정 예정*/
            Toast.makeText(this, "All Challenges Completed! Loading New Challenges..", Toast.LENGTH_LONG).show()
            loadNewChallenges()
        }
    }

    private fun updateProgressBar() {
        val progress = (completedChallenges.toFloat() / totalChallenges * 100).toInt() //완료된 챌린지 비율 계산
        binding.challengeProgress.progress = progress //진행률 반영
    }
}
