package com.example.healthappproject


import android.os.Bundle // 액티비티의 상태를 저장하거나 복원
import android.os.SystemClock // 기기 부팅 후 경과된 시간을 측정하는 기능을 제공
import androidx.appcompat.app.AppCompatActivity
import com.example.healthappproject.databinding.ActivityRecordBinding // 뷰 바인딩

class RecordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecordBinding

    private var startTime: Long = 0 // 스톱워치를 시작한 시점 저장
    private var isTiming = false //스톱워치 진행 여부

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) /* 부모클래스의 oncreate 호출
         savedInstanceState: 액티비티가 이전에 종료되었을 경우, 그 상태를 Bundle 객체에 저장 */

        setContentView(binding.root) //binding.root는 XML 레이아웃 파일의 최상위 뷰,액티비티의 화면에 루트 뷰와 그 아래의 모든 자식 뷰를 표시

        binding.buttonStartTimer.setOnClickListener { /* buttonStartTimer 클릭 시 스톱워치를 시작하거나 중지함,
        isTiming 값에 따라 startTimer() 또는 stopTimer()가 호출 */
            if (isTiming) {
                stopTimer()
            } else {
                startTimer()
            }
        }
    }

    private fun startTimer() {
        startTime = SystemClock.elapsedRealtime() //부팅 이후 경과된 시간 반환, 스톱워치 시작 지점을 저장함
        isTiming = true // 스톱워치가 진행 중..
        binding.buttonStartTimer.text = "Stop" // 버튼 텍스트 변경, 텍스트가 아닌 아이콘으로 바꿀 수 있을지 고민중
    }

    private fun stopTimer() {
        val elapsedMillis = SystemClock.elapsedRealtime() - startTime // 경과 시간을 계산
        val seconds = (elapsedMillis / 1000) % 60
        val minutes = (elapsedMillis / 1000) / 60

        binding.textTodayTime.text = String.format("Today: %02d:%02d", minutes, seconds)
        isTiming = false //스톱워치 중지된 상태
        binding.buttonStartTimer.text = "Start"
    }
}

