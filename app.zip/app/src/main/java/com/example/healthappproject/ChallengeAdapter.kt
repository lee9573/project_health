package com.example.healthappproject

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.CompoundButton
import androidx.recyclerview.widget.RecyclerView
import com.example.healthappproject.databinding.ItemChallengeBinding

//어댑터 정의 - 챌린지 목록과 상태 변경 콜백 함수 전달받음
class ChallengeAdapter(
    private val challenges: List<String>, // 챌린지 이름 리스트
    private val onChallengeCheckedChanged: (Boolean) -> Unit // 체크 상태 변경 시 호출되는 콜백 함수
) : RecyclerView.Adapter<ChallengeAdapter.ChallengeViewHolder>() { // RecyclerView 어댑터 상속

    // 뷰 홀더 클래스 정의 - 각 챌린지 항목을 뷰와 결합하여 데이터를 바인딩
    inner class ChallengeViewHolder(private val binding: ItemChallengeBinding) : RecyclerView.ViewHolder(binding.root) {

        // 챌린지 이름을 바인딩하고 체크박스의 초기 상태와 이벤트 리스너 설정
        fun bind(challenge: String) {
            binding.challengeCheckBox.text = challenge // 체크박스에 챌린지 이름 설정
            binding.challengeCheckBox.isChecked = false // 초기 상태는 체크되지 않은 상태


            binding.challengeCheckBox.setOnCheckedChangeListener { _, isChecked ->
                onChallengeCheckedChanged(isChecked) // 현재 체크 상태를 콜백 함수로 전달
            }
        }
    }

    //item_challenge 레이아웃을 inflate하여 ViewHolder 생성
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChallengeViewHolder {
        val binding = ItemChallengeBinding.inflate(LayoutInflater.from(parent.context), parent, false) // item_challenge 레이아웃 바인딩
        return ChallengeViewHolder(binding) // 생성된 ViewHolder 반환
    }

    //챌린지 리스트에서 해당 위치의 데이터를 ViewHolder에 전달하여 바인딩
    override fun onBindViewHolder(holder: ChallengeViewHolder, position: Int) {
        holder.bind(challenges[position]) // 지정된 위치의 챌린지를 ViewHolder에 바인딩
    }

    // 리스트 전체 아이템 수 반환 - RecyclerView의 항목 수를 결정
    override fun getItemCount() = challenges.size // 챌린지 리스트의 크기 반환
}
